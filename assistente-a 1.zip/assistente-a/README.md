# A — assistente de voz para músicas (Android)

Assistente pessoal em português do Brasil que controla músicas e volume por voz, no celular Android, com saída para caixa Bluetooth.

> **Baixar o app:** [AssistenteA.apk (última versão)](https://github.com/alef1995/assistente-a/releases/latest/download/AssistenteA.apk)

---

## O que já funciona (Fase 1 + início da Fase 2)

| Fale | O que acontece |
|---|---|
| "A, tocar Matuê" · "A, tocar Evidências" | Pede a música ao Spotify / YouTube Music / Deezer, que busca e começa a tocar |
| "A, tocar músicas do Henrique e Juliano" | Pede ao player para tocar o artista |
| "A, próxima música" · "música anterior" | Pula / volta |
| "A, pausar" · "A, continuar" · "A, parar a música" | Controla o player que estiver tocando |
| "A, aumentar volume" · "diminuir volume" | Muda ~10% do volume de mídia |
| "A, volume 50%" · "volume cinquenta por cento" | Define o volume exato |
| "A, silenciar" · "tirar do mudo" | Mudo do volume de mídia |
| "Que música é essa?" | Diz o nome da música (precisa do acesso a notificações) |
| "Ajuda" | Lista os comandos |

A palavra "A" é opcional quando você toca no microfone. Na **escuta contínua** ela é obrigatória.

A A responde por voz e a música abaixa automaticamente enquanto ela fala.

## Instalar no celular

1. No celular, abra o link **Baixar o app** acima.
2. Toque no arquivo baixado. Se o Android pedir, permita **"Instalar apps desconhecidos"** para o navegador.
3. Abra a **A**, toque no microfone e permita o uso do microfone.
4. (Recomendado) Toque em **"Permitir mostrar a música atual"** e ative a **A** na lista. Isso permite ver o nome da música, controlar o player diretamente e, com o Spotify já aberto, trocar de música sem sair da A.

Para atualizar, basta baixar e instalar de novo, por cima.

### Requisitos
- Android 8.0 ou superior.
- App **Google** instalado (é ele que faz o reconhecimento de voz) e internet.
- Um app de música: **Spotify** (recomendado), YouTube Music, Deezer ou Amazon Music.
- Voz em português: *Configurações › Sistema › Idiomas › Saída de texto para fala* → Português (Brasil).

## Como foi feito (arquitetura)

App **Android nativo em Kotlin**, sem bibliotecas externas — só recursos oficiais do Android:

```
MainActivity (tela)  ──►  SpeechListener   reconhecimento de voz pt-BR (SpeechRecognizer)
        │                 CommandParser    frase → comando (palavras-chave, offline, testado)
        │                 VolumeController volume de mídia (AudioManager) — vale para o Bluetooth
        │                 MediaControl     play/pausa/próxima no player ativo (MediaSession / teclas de mídia)
        │                 MusicLauncher    "tocar X" pelo mecanismo oficial MEDIA_PLAY_FROM_SEARCH
        └──────────────►  Speaker          respostas faladas (TextToSpeech) com redução da música
```

**Por que não usar o YouTube direto (erro 153)?** O player embutido do YouTube não permite reprodução automática nem em segundo plano por apps de terceiros. Em vez disso, a A pede a música ao app de streaming pelo mesmo caminho oficial que o Google Assistente usa — o app de música faz a busca e toca, inclusive pela caixa Bluetooth.

## Compilação automática

Cada envio para a branch `main` dispara o GitHub Actions (`.github/workflows/build.yml`), que:
1. roda os testes do interpretador de comandos;
2. compila o APK;
3. publica o APK na página **Releases** com o link fixo acima.

Nenhum computador é necessário. O APK é assinado com uma chave fixa de depuração (`keystore/`), para que as atualizações instalem por cima.

## Limitações conhecidas (honestas)

- **"Tocar X" abre o app de música** na primeira vez. Com o acesso a notificações concedido e o Spotify já aberto, os pedidos seguintes podem ser feitos sem trocar de tela (se o player aceitar; senão a A abre o app automaticamente).
- **Spotify gratuito** pode tocar o artista em modo aleatório em vez da faixa exata — é regra do Spotify.
- **Escuta contínua** só funciona com a tela da A aberta (a tela fica acesa). O Android toca um "bip" a cada reinício do microfone em alguns aparelhos.
- **"A" é uma palavra muito curta** para palavra de ativação: em português "a" aparece em muitas frases. Por isso, na escuta contínua, a A só age se a frase for um comando reconhecido.

## Próximas fases

- **Fase 2:** escolher a faixa exata via API oficial do Spotify (Web API / App Remote), exibir capa do álbum.
- **Fase 3:** escuta com tela apagada usando serviço em primeiro plano + detector de palavra de ativação offline (ex.: Vosk Android ou Porcupine), inicialização automática.

Detalhes e guia de testes: [docs/TESTES.md](docs/TESTES.md).
