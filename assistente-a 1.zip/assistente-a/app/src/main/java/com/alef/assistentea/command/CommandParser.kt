package com.alef.assistentea.command

import java.text.Normalizer
import java.util.Locale

/**
 * Converte o texto reconhecido (português do Brasil) em um [Command].
 *
 * Funciona por palavras-chave, sem IA: é rápido, previsível e funciona offline.
 * Para entender uma frase nova, basta acrescentar a palavra na lista certa.
 */
object CommandParser {

    // Formas como o reconhecedor costuma transcrever a palavra de ativação "A".
    private val WAKE_PREFIXES = listOf(
        listOf("ei", "a"), listOf("hey", "a"), listOf("oi", "a"), listOf("e", "a"),
        listOf("assistente"), listOf("a"), listOf("ah"), listOf("ha"), listOf("aa")
    )

    // Verbos que iniciam um pedido de música.
    private val PLAY_PREFIXES = listOf(
        listOf("eu", "quero", "ouvir"), listOf("quero", "ouvir"), listOf("quero", "escutar"),
        listOf("toca", "ai"), listOf("toca", "pra", "mim"), listOf("toca", "para", "mim"),
        listOf("tocar"), listOf("toca"), listOf("toque"), listOf("tocando"),
        listOf("reproduzir"), listOf("reproduz"), listOf("reproduza"),
        listOf("colocar"), listOf("coloca"), listOf("coloque"),
        listOf("botar"), listOf("bota"), listOf("bote"), listOf("poe"),
        listOf("ouvir"), listOf("escutar"), listOf("play")
    )

    // Palavras que, sozinhas depois de "tocar", significam "continuar".
    private val RESUME_ONLY = setOf("", "musica", "a musica", "de novo", "novamente", "o som")

    /** Escolhe a primeira alternativa do reconhecedor que vira um comando conhecido. */
    fun parseBest(alternatives: List<String>): ParseResult {
        var first: ParseResult? = null
        for (alt in alternatives) {
            val r = parse(alt)
            if (first == null) first = r
            if (r.command !is Command.Unknown) return r
        }
        return first ?: ParseResult(Command.Unknown(""), false)
    }

    fun parse(raw: String): ParseResult {
        // Tokens originais (com acento) e normalizados (sem acento, minúsculos), alinhados 1:1.
        val original = Regex("[\\p{L}\\p{N}%]+").findAll(raw).map { it.value }.toMutableList()
        val norm = original.map { normalize(it) }.toMutableList()
        // "50%" vira "50" e "%"; "por cento" vira "%"
        splitPercent(original, norm)

        var start = 0
        var hadWake = false
        for (prefix in WAKE_PREFIXES) {
            if (startsWith(norm, 0, prefix)) {
                start = prefix.size
                hadWake = true
                break
            }
        }
        if (hadWake && start >= norm.size) return ParseResult(Command.WakeOnly, true)

        val tokens = norm.subList(start, norm.size)
        val origTokens = original.subList(start, original.size)
        val text = tokens.joinToString(" ")
        if (text.isBlank()) return ParseResult(Command.Unknown(raw), hadWake)

        return ParseResult(match(tokens, origTokens, text), hadWake)
    }

    private fun match(tokens: List<String>, orig: List<String>, text: String): Command {
        // 1) Pedido de música vem primeiro: o nome da música pode conter qualquer palavra
        //    ("tocar Próxima Parada", "tocar Volta pra Mim").
        for (prefix in PLAY_PREFIXES) {
            if (startsWith(tokens, 0, prefix)) {
                // "coloca o volume em 30" não é pedido de música
                if (tokens.drop(prefix.size).take(2).contains("volume")) break
                return playCommand(tokens.drop(prefix.size), orig.drop(prefix.size))
            }
        }

        // 2) Volume com número: "volume 50%", "volume em cinquenta", "coloca o volume no 30"
        if (has(text, "volume", "som")) {
            parseVolumeNumber(tokens)?.let { return Command.SetVolume(it.coerceIn(0, 100)) }
            if (has(text, "maximo", "no talo", "tudo")) return Command.SetVolume(100)
            if (has(text, "minimo")) return Command.SetVolume(10)
            if (has(text, "metade", "meio")) return Command.SetVolume(50)
        }
        if (tokens.size <= 3 && tokens.contains("%")) {
            parseVolumeNumber(tokens)?.let { return Command.SetVolume(it.coerceIn(0, 100)) }
        }

        // 3) Mudo
        if (has(text, "tirar do mudo", "tira do mudo", "desmutar", "desmuta", "desativar o mudo",
                "desativa o mudo", "ativar o som", "ativa o som", "religar o som", "liga o som")) {
            return Command.Unmute
        }
        if (has(text, "silenciar", "silencia", "silencie", "silencio", "mudo", "mutar", "muta", "mute")) {
            return Command.Mute
        }

        // 4) Aumentar / diminuir
        val mentionsVolume = has(text, "volume", "som", "audio")
        if (has(text, "mais alto", "aumenta mais", "aumente") ||
            (mentionsVolume && has(text, "aumentar", "aumenta", "sobe", "subir", "suba", "levanta"))) {
            return Command.VolumeUp
        }
        if (has(text, "mais baixo", "abaixa mais", "abaixe") ||
            (mentionsVolume && has(text, "diminuir", "diminui", "diminua", "abaixar", "abaixa",
                "baixa", "baixar", "reduzir", "reduz", "desce", "descer"))) {
            return Command.VolumeDown
        }
        if (text == "aumentar" || text == "aumenta") return Command.VolumeUp
        if (text == "diminuir" || text == "diminui" || text == "abaixar" || text == "abaixa") return Command.VolumeDown

        // 5) Qual música está tocando? (antes de "próxima"/"parar" por causa de "tocando")
        if (has(text, "que musica e essa", "qual musica", "que musica", "o que esta tocando",
                "o que ta tocando", "nome da musica", "que som e esse", "quem canta")) {
            return Command.NowPlaying
        }

        // 6) Navegação
        if (has(text, "anterior", "volta a musica", "voltar a musica", "volta uma", "voltar uma",
                "musica de antes", "a de antes")) {
            return Command.Previous
        }
        if (has(text, "proxima", "proximo", "pula", "pular", "pule", "passa", "passar", "passe",
                "avanca", "avancar", "seguinte", "troca a musica", "trocar a musica", "outra musica")) {
            return Command.Next
        }

        // 7) Continuar (antes de pausar: "despausar" contém "pausar")
        if (has(text, "despausar", "despausa", "continuar", "continua", "continue", "retomar", "retoma",
                "volta a tocar", "voltar a tocar", "pode tocar", "solta o som", "play", "resume")) {
            return Command.Resume
        }

        // 8) Pausar / parar
        if (has(text, "pausar", "pausa", "pause", "pausado", "da um pause", "segura")) {
            return Command.Pause
        }
        if (has(text, "parar", "para a musica", "para de tocar", "para musica", "para o som",
                "para tudo", "stop", "desliga a musica", "desligar a musica", "chega") || text == "para") {
            return Command.Stop
        }

        // 9) Ajuda
        if (has(text, "ajuda", "o que voce faz", "o que voce sabe", "comandos", "socorro")) {
            return Command.Help
        }

        return Command.Unknown(orig.joinToString(" "))
    }

    private fun playCommand(rest: List<String>, restOrig: List<String>): Command {
        var t = rest
        var o = restOrig

        // Remove sufixos como "no Spotify", "no YouTube"
        val appSuffix = listOf("no spotify", "no youtube", "no youtube music", "no deezer", "pra mim", "para mim", "por favor")
        var changed = true
        while (changed) {
            changed = false
            for (s in appSuffix) {
                val parts = s.split(" ")
                if (t.size > parts.size && t.takeLast(parts.size) == parts) {
                    t = t.dropLast(parts.size); o = o.dropLast(parts.size); changed = true
                }
            }
        }

        val joined = t.joinToString(" ")
        if (joined in RESUME_ONLY) return Command.Resume

        // "músicas do Henrique e Juliano", "algo da Marília Mendonça", "um pouco de Matuê"
        val artistPrefixes = listOf(
            listOf("as", "musicas", "do"), listOf("as", "musicas", "da"), listOf("as", "musicas", "de"),
            listOf("as", "musicas", "dos"), listOf("as", "musicas", "das"),
            listOf("umas", "musicas", "do"), listOf("umas", "musicas", "da"), listOf("umas", "musicas", "de"),
            listOf("musicas", "do"), listOf("musicas", "da"), listOf("musicas", "de"),
            listOf("musicas", "dos"), listOf("musicas", "das"),
            listOf("musica", "do"), listOf("musica", "da"), listOf("musica", "de"),
            listOf("algo", "do"), listOf("algo", "da"), listOf("algo", "de"),
            listOf("alguma", "coisa", "do"), listOf("alguma", "coisa", "da"), listOf("alguma", "coisa", "de"),
            listOf("um", "pouco", "do"), listOf("um", "pouco", "da"), listOf("um", "pouco", "de"),
            listOf("o", "artista"), listOf("a", "artista"), listOf("a", "banda"), listOf("o", "cantor"), listOf("a", "cantora")
        )
        for (p in artistPrefixes) {
            if (t.size > p.size && startsWith(t, 0, p)) {
                val artist = o.drop(p.size).joinToString(" ")
                return Command.Play(query = artist, artist = artist)
            }
        }

        // "a música Evidências", "música Evidências"
        val songPrefixes = listOf(listOf("a", "musica"), listOf("musica"), listOf("a", "cancao"))
        for (p in songPrefixes) {
            if (t.size > p.size && startsWith(t, 0, p)) {
                return Command.Play(query = o.drop(p.size).joinToString(" "))
            }
        }

        val query = o.joinToString(" ").replace(" %", "%").trim()
        if (query.isEmpty()) return Command.Resume
        return Command.Play(query = query)
    }

    // ------------------------------------------------------------------ números

    private val UNITS = mapOf(
        "zero" to 0, "um" to 1, "uma" to 1, "dois" to 2, "duas" to 2, "tres" to 3, "quatro" to 4,
        "cinco" to 5, "seis" to 6, "sete" to 7, "oito" to 8, "nove" to 9, "dez" to 10, "onze" to 11,
        "doze" to 12, "treze" to 13, "catorze" to 14, "quatorze" to 14, "quinze" to 15,
        "dezesseis" to 16, "dezessete" to 17, "dezoito" to 18, "dezenove" to 19
    )
    private val TENS = mapOf(
        "vinte" to 20, "trinta" to 30, "quarenta" to 40, "cinquenta" to 50, "sessenta" to 60,
        "setenta" to 70, "oitenta" to 80, "noventa" to 90, "cem" to 100, "cento" to 100
    )

    /** Procura um número (dígitos ou por extenso) na frase. */
    internal fun parseVolumeNumber(tokens: List<String>): Int? {
        tokens.firstOrNull { it.all(Char::isDigit) && it.isNotEmpty() }?.let { return it.toIntOrNull() }

        var total = 0
        var found = false
        var i = 0
        while (i < tokens.size) {
            val w = tokens[i]
            val v = TENS[w] ?: UNITS[w]
            if (v != null) {
                // ignora "um"/"uma" como artigo ("um pouco"), a menos que seja o único número
                if ((w == "um" || w == "uma") && !found && i + 1 < tokens.size && tokens[i + 1] !in setOf("%", "por")) {
                    i++; continue
                }
                total += v
                found = true
            } else if (w == "e" && found) {
                // "trinta e cinco"
            } else if (found) {
                break
            }
            i++
        }
        return if (found) total else null
    }

    // ------------------------------------------------------------------ utilidades

    fun normalize(s: String): String {
        val lower = s.lowercase(Locale.ROOT)
        val noAccents = Normalizer.normalize(lower, Normalizer.Form.NFD).replace(Regex("\\p{Mn}+"), "")
        return noAccents.replace(Regex("[^a-z0-9%]"), "")
    }

    private fun splitPercent(original: MutableList<String>, norm: MutableList<String>) {
        var i = 0
        while (i < norm.size) {
            val n = norm[i]
            if (n.length > 1 && n.endsWith("%")) {
                norm[i] = n.dropLast(1); original[i] = original[i].dropLast(1)
                norm.add(i + 1, "%"); original.add(i + 1, "%")
            } else if (n == "por" && i + 1 < norm.size && norm[i + 1] == "cento") {
                norm[i] = "%"; original[i] = "%"
                norm.removeAt(i + 1); original.removeAt(i + 1)
            }
            i++
        }
    }

    private fun startsWith(tokens: List<String>, from: Int, prefix: List<String>): Boolean {
        if (tokens.size - from < prefix.size) return false
        for (k in prefix.indices) if (tokens[from + k] != prefix[k]) return false
        return true
    }

    /** Verifica se o texto contém alguma das expressões como palavras inteiras. */
    private fun has(text: String, vararg phrases: String): Boolean {
        val padded = " $text "
        return phrases.any { padded.contains(" $it ") }
    }
}
