package com.alef.assistentea

import android.Manifest
import android.animation.ValueAnimator
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.Switch
import android.widget.TextView
import com.alef.assistentea.command.Command
import com.alef.assistentea.command.CommandParser
import com.alef.assistentea.media.MediaControl
import com.alef.assistentea.media.TrackInfo
import com.alef.assistentea.media.VolumeController
import com.alef.assistentea.music.MusicLauncher
import com.alef.assistentea.voice.SpeechListener
import com.alef.assistentea.voice.Speaker

/**
 * Tela única da assistente A.
 *
 * Fluxo: toque no microfone → [SpeechListener] reconhece a frase → [CommandParser]
 * transforma em [Command] → [execute] age (volume, player, música) → [Speaker] responde.
 */
class MainActivity : Activity(), SpeechListener.Callback, Speaker.Listener {

    private enum class UiState { IDLE, LISTENING, PROCESSING, SPEAKING }

    companion object {
        private const val REQ_MIC = 10
    }

    // Componentes
    private lateinit var speech: SpeechListener
    private lateinit var speaker: Speaker
    private lateinit var volume: VolumeController
    private lateinit var media: MediaControl
    private lateinit var music: MusicLauncher

    // Views
    private lateinit var micButton: ImageButton
    private lateinit var micRing: View
    private lateinit var statusText: TextView
    private lateinit var heardText: TextView
    private lateinit var replyText: TextView
    private lateinit var trackTitle: TextView
    private lateinit var trackArtist: TextView
    private lateinit var playPauseButton: ImageButton
    private lateinit var volumeText: TextView
    private lateinit var playerChip: TextView
    private lateinit var mediaAccessButton: TextView
    private lateinit var continuousSwitch: Switch

    // Estado
    private val main = Handler(Looper.getMainLooper())
    private var state = UiState.IDLE
    private var continuous = false
    private var manualTrigger = true
    private var isResumedNow = false
    private var micDeniedOnce = false
    private var duckedIndex: Int? = null
    private var pulse: ValueAnimator? = null
    private var smoothedLevel = 0f

    private val relisten = Runnable {
        if (continuous && isResumedNow && state == UiState.IDLE && !speech.isListening &&
            !speaker.isSpeaking && hasMicPermission()
        ) {
            startListening(manual = false)
        }
    }

    // ================================================================== ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        micButton = findViewById(R.id.micButton)
        micRing = findViewById(R.id.micRing)
        statusText = findViewById(R.id.statusText)
        heardText = findViewById(R.id.heardText)
        replyText = findViewById(R.id.replyText)
        trackTitle = findViewById(R.id.trackTitle)
        trackArtist = findViewById(R.id.trackArtist)
        playPauseButton = findViewById(R.id.playPauseButton)
        volumeText = findViewById(R.id.volumeText)
        playerChip = findViewById(R.id.playerChip)
        mediaAccessButton = findViewById(R.id.mediaAccessButton)
        continuousSwitch = findViewById(R.id.continuousSwitch)

        speech = SpeechListener(this, this)
        speaker = Speaker(this, this)
        volume = VolumeController(this)
        media = MediaControl(this)
        music = MusicLauncher(this)

        micButton.setOnClickListener { onMicTapped() }

        playPauseButton.setOnClickListener {
            if (media.isMusicPlaying()) media.pause() else media.play()
            main.postDelayed({ refreshPlayButton() }, 500)
        }
        findViewById<ImageButton>(R.id.nextButton).setOnClickListener { media.next() }
        findViewById<ImageButton>(R.id.prevButton).setOnClickListener { media.previous() }
        findViewById<ImageButton>(R.id.volUpButton).setOnClickListener { volume.up(); refreshVolume() }
        findViewById<ImageButton>(R.id.volDownButton).setOnClickListener { volume.down(); refreshVolume() }

        playerChip.setOnClickListener {
            if (music.installedPlayers().isEmpty()) {
                showReply("Nenhum app de música encontrado. Instale o Spotify ou o YouTube Music.", error = true)
            } else {
                music.cyclePreferred()
                updatePlayerChip()
            }
        }

        mediaAccessButton.setOnClickListener {
            showReply("Ative a \"A\" na lista e volte para o app.")
            try {
                startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        }

        continuousSwitch.setOnCheckedChangeListener { _, checked -> setContinuous(checked) }

        updatePlayerChip()
        setState(UiState.IDLE)
    }

    override fun onResume() {
        super.onResume()
        isResumedNow = true
        refreshVolume()
        refreshPlayButton()
        mediaAccessButton.visibility = if (media.hasNotificationAccess()) View.GONE else View.VISIBLE
        media.observe { showTrack(it) }
        updatePlayerChip()
        if (continuous) main.postDelayed(relisten, 500)
    }

    override fun onPause() {
        super.onPause()
        isResumedNow = false
        main.removeCallbacks(relisten)
        if (speech.isListening) {
            speech.cancel()
            restoreDuck()
            setState(UiState.IDLE)
        }
        media.stopObserving()
    }

    override fun onDestroy() {
        super.onDestroy()
        main.removeCallbacksAndMessages(null)
        pulse?.cancel()
        speech.destroy()
        speaker.shutdown()
    }

    // ================================================================== microfone

    private fun onMicTapped() {
        when (state) {
            UiState.LISTENING -> {
                speech.cancel()
                restoreDuck()
                setState(UiState.IDLE)
                return
            }
            UiState.SPEAKING -> speaker.stop()
            else -> {}
        }
        withMicPermission { startListening(manual = true) }
    }

    private fun hasMicPermission() =
        checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    private var afterPermission: (() -> Unit)? = null

    private fun withMicPermission(action: () -> Unit) {
        if (hasMicPermission()) {
            action()
            return
        }
        if (micDeniedOnce && !shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
            // Negado com "não perguntar novamente": só pelas configurações
            showReply("Libere o microfone em Permissões › Microfone.", error = true)
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
            )
            return
        }
        afterPermission = action
        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_MIC)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_MIC) return
        if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
            afterPermission?.invoke()
        } else {
            micDeniedOnce = true
            if (continuous) continuousSwitch.isChecked = false
            showReply("Sem o microfone eu não consigo ouvir você. Toque no botão para permitir.", error = true)
        }
        afterPermission = null
    }

    private fun startListening(manual: Boolean) {
        if (!speech.isAvailable()) {
            showReply(
                "Reconhecimento de voz indisponível. Instale ou atualize o app Google e ative a digitação por voz.",
                error = true
            )
            return
        }
        if (speech.isListening) return
        if (speaker.isSpeaking) speaker.stop()
        manualTrigger = manual
        // Abaixa a música para o microfone ouvir melhor (só no modo de toque)
        if (manual && duckedIndex == null && media.isMusicPlaying()) {
            duckedIndex = volume.duck(15)
        }
        heardText.text = ""
        setState(UiState.LISTENING)
        speech.start()
    }

    private fun restoreDuck() {
        duckedIndex?.let { volume.restoreIndex(it) }
        duckedIndex = null
    }

    // ================================================================== SpeechListener.Callback

    override fun onListeningStarted() {
        if (state != UiState.LISTENING) setState(UiState.LISTENING)
    }

    override fun onPartialText(text: String) {
        heardText.text = "“$text”"
    }

    override fun onVoiceLevel(rmsDb: Float) {
        if (state != UiState.LISTENING) return
        val level = ((rmsDb + 2f) / 12f).coerceIn(0f, 1f)
        smoothedLevel = smoothedLevel * 0.6f + level * 0.4f
        val scale = 0.9f + smoothedLevel * 0.35f
        micRing.scaleX = scale
        micRing.scaleY = scale
    }

    override fun onFinalResults(alternatives: List<String>) {
        restoreDuck()
        val best = CommandParser.parseBest(alternatives)
        heardText.text = "“${alternatives.first()}”"

        // No modo contínuo, só reage se a frase começar com "A"
        if (continuous && !manualTrigger && !best.hadWakeWord) {
            setState(UiState.IDLE)
            main.postDelayed(relisten, 250)
            return
        }
        setState(UiState.PROCESSING)
        execute(best.command)
    }

    override fun onListenError(message: String, silent: Boolean) {
        restoreDuck()
        setState(UiState.IDLE)
        if (continuous && !manualTrigger && silent) {
            main.postDelayed(relisten, 250)
            return
        }
        if (silent) {
            showReply(message)
        } else {
            reply(message, error = true)
        }
        if (continuous) main.postDelayed(relisten, 2500)
    }

    // ================================================================== Speaker.Listener

    override fun onSpeakStart() = setState(UiState.SPEAKING)

    override fun onSpeakDone() {
        if (state == UiState.SPEAKING || state == UiState.PROCESSING) setState(UiState.IDLE)
    }

    override fun onTtsProblem(message: String) = showReply(message, error = true)

    // ================================================================== comandos

    private fun execute(cmd: Command) {
        when (cmd) {
            is Command.Play -> playMusic(cmd)

            Command.Pause -> { media.pause(); reply("Pausado.") }
            Command.Stop -> { media.stop(); reply("Música parada.") }
            Command.Resume -> reply("Continuando.") { media.play() }
            Command.Next -> { media.next(); reply("Próxima música.") }
            Command.Previous -> { media.previous(); reply("Música anterior.") }

            Command.VolumeUp -> reply("Volume em ${volume.up()} por cento.")
            Command.VolumeDown -> reply("Volume em ${volume.down()} por cento.")
            is Command.SetVolume -> reply("Volume em ${volume.setPercent(cmd.percent)} por cento.")
            Command.Mute -> reply("Silenciando.") { volume.mute() }
            Command.Unmute -> { volume.unmute(); reply("Som ativado.") }

            Command.NowPlaying -> {
                val t = media.nowPlaying()
                when {
                    t != null -> reply("Está tocando ${t.title}" + (t.artist?.let { ", de $it" } ?: "") + ".")
                    !media.hasNotificationAccess() ->
                        reply("Para eu saber o nome da música, toque em \"Permitir mostrar a música atual\".")
                    else -> reply("Não tem nenhuma música tocando agora.")
                }
            }

            Command.Help -> reply(
                "Você pode dizer: tocar e o nome da música ou do artista, pausar, continuar, " +
                    "próxima, volume cinquenta por cento, aumentar ou diminuir o volume, e silenciar."
            )

            Command.WakeOnly -> reply("Oi! Pode falar.") { startListening(manual = true) }

            is Command.Unknown -> reply("Não entendi. Diga \"ajuda\" para ouvir os comandos.")
        }
        refreshVolume()
        main.postDelayed({ refreshPlayButton() }, 600)
    }

    private fun playMusic(cmd: Command.Play) {
        val what = cmd.artist?.let { "músicas de $it" } ?: cmd.query
        val before = media.nowPlaying()
        reply("Tocando $what.") {
            when (val result = music.play(cmd.query, cmd.artist, media)) {
                is MusicLauncher.Result.Started -> {
                    showReply("▶ $what · ${result.playerLabel}")
                    if (result.viaSession) verifySessionPlayback(cmd, before)
                }
                is MusicLauncher.Result.OpenedSearch ->
                    showReply("Abri a busca no ${result.playerLabel}. Toque na música para começar.")
                MusicLauncher.Result.NoPlayer ->
                    reply("Não encontrei um app de música. Instale o Spotify ou o YouTube Music.", error = true)
            }
        }
    }

    /**
     * O pedido "em segundo plano" pode ser ignorado por alguns players.
     * Se depois de alguns segundos nada mudou, abre o app de música do jeito tradicional.
     */
    private fun verifySessionPlayback(cmd: Command.Play, before: TrackInfo?) {
        main.postDelayed({
            val now = media.nowPlaying()
            val changed = now != null && now.playing && (before == null || now.title != before.title || !before.playing)
            if (!changed) {
                when (val r = music.play(cmd.query, cmd.artist, media = null)) {
                    is MusicLauncher.Result.Started -> showReply("▶ Abrindo no ${r.playerLabel}…")
                    is MusicLauncher.Result.OpenedSearch -> showReply("Abri a busca no ${r.playerLabel}.")
                    MusicLauncher.Result.NoPlayer -> showReply("Não consegui iniciar a música.", error = true)
                }
            }
        }, 3500)
    }

    /** Mostra e fala a resposta. [after] roda quando a fala terminar. */
    private fun reply(text: String, error: Boolean = false, after: (() -> Unit)? = null) {
        showReply(text, error)
        speaker.speak(text) {
            after?.invoke()
            refreshVolume()
            if (continuous && isResumedNow) main.postDelayed(relisten, 400)
        }
    }

    private fun showReply(text: String, error: Boolean = false) {
        replyText.setTextColor(getColor(if (error) R.color.error else R.color.cyan))
        replyText.text = text
    }

    // ================================================================== modo contínuo

    private fun setContinuous(on: Boolean) {
        continuous = on
        if (on) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            showReply("Escuta contínua ligada. Comece a frase com \"A\". Ex.: \"A, pausar\".")
            withMicPermission { main.postDelayed(relisten, 300) }
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            main.removeCallbacks(relisten)
            if (speech.isListening) {
                speech.cancel()
                setState(UiState.IDLE)
            }
            showReply("Escuta contínua desligada.")
        }
    }

    // ================================================================== interface

    private fun setState(s: UiState) {
        state = s
        pulse?.cancel()
        pulse = null
        when (s) {
            UiState.IDLE -> {
                statusText.text = if (continuous) "Aguardando \"A…\"" else getString(R.string.status_idle)
                micButton.setImageResource(R.drawable.ic_mic)
                micRing.animate().alpha(0f).scaleX(1f).scaleY(1f).setDuration(200).start()
            }
            UiState.LISTENING -> {
                statusText.text = if (continuous && !manualTrigger) "Ouvindo… (diga \"A, …\")"
                else getString(R.string.status_listening)
                micButton.setImageResource(R.drawable.ic_stop)
                micRing.animate().cancel()
                micRing.alpha = 1f
            }
            UiState.PROCESSING -> {
                statusText.text = getString(R.string.status_processing)
                micButton.setImageResource(R.drawable.ic_mic)
                micRing.alpha = 0.4f
            }
            UiState.SPEAKING -> {
                statusText.text = getString(R.string.status_speaking)
                micButton.setImageResource(R.drawable.ic_mic)
                micRing.animate().cancel()
                micRing.alpha = 0.7f
                pulse = ValueAnimator.ofFloat(0.95f, 1.15f).apply {
                    duration = 450
                    repeatMode = ValueAnimator.REVERSE
                    repeatCount = ValueAnimator.INFINITE
                    addUpdateListener {
                        val v = it.animatedValue as Float
                        micRing.scaleX = v
                        micRing.scaleY = v
                    }
                    start()
                }
            }
        }
    }

    private fun showTrack(t: TrackInfo?) {
        if (t == null) {
            trackTitle.text = getString(R.string.nothing_playing)
            trackArtist.text = if (media.hasNotificationAccess()) "" else "Permita o acesso abaixo para ver o nome da música"
        } else {
            trackTitle.text = t.title
            trackArtist.text = listOfNotNull(t.artist, t.appName).joinToString(" · ")
        }
        refreshPlayButton()
    }

    private fun refreshPlayButton() {
        playPauseButton.setImageResource(if (media.isMusicPlaying()) R.drawable.ic_pause else R.drawable.ic_play)
    }

    private fun refreshVolume() {
        volumeText.text = if (volume.isMuted()) "Volume: mudo" else "Volume: ${volume.percent()}%"
    }

    private fun updatePlayerChip() {
        val installed = music.installedPlayers()
        playerChip.text = when {
            installed.isEmpty() -> "Sem app de música"
            else -> "Player: " + (music.preferredPlayer?.label ?: "automático")
        }
    }
}
