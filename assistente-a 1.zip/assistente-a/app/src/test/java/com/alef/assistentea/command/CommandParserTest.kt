package com.alef.assistentea.command

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CommandParserTest {

    private fun cmd(s: String) = CommandParser.parse(s).command

    @Test fun tocarArtista() {
        assertEquals(Command.Play("Matuê"), cmd("A, tocar Matuê"))
        assertEquals(Command.Play("Evidências"), cmd("A tocar Evidências."))
        assertEquals(Command.Play("Evidências"), cmd("toca a música Evidências"))
    }

    @Test fun tocarMusicasDoArtista() {
        assertEquals(
            Command.Play("Henrique e Juliano", "Henrique e Juliano"),
            cmd("A, tocar músicas do Henrique e Juliano.")
        )
        assertEquals(
            Command.Play("Marília Mendonça", "Marília Mendonça"),
            cmd("coloca umas músicas da Marília Mendonça no Spotify")
        )
    }

    @Test fun nomeDeMusicaComPalavrasDeComando() {
        assertEquals(Command.Play("Próxima Parada"), cmd("tocar Próxima Parada"))
    }

    @Test fun navegacao() {
        assertEquals(Command.Next, cmd("A, próxima música."))
        assertEquals(Command.Next, cmd("pula essa"))
        assertEquals(Command.Previous, cmd("música anterior"))
        assertEquals(Command.Pause, cmd("A, pausar."))
        assertEquals(Command.Resume, cmd("A, continuar."))
        assertEquals(Command.Resume, cmd("despausar"))
        assertEquals(Command.Stop, cmd("A, parar a música."))
    }

    @Test fun volume() {
        assertEquals(Command.VolumeUp, cmd("A, aumentar volume."))
        assertEquals(Command.VolumeDown, cmd("A, diminuir volume."))
        assertEquals(Command.VolumeDown, cmd("abaixa o som"))
        assertEquals(Command.SetVolume(50), cmd("A, volume 50%."))
        assertEquals(Command.SetVolume(50), cmd("volume cinquenta por cento"))
        assertEquals(Command.SetVolume(35), cmd("coloca o volume em trinta e cinco"))
        assertEquals(Command.SetVolume(100), cmd("volume máximo"))
        assertEquals(Command.Mute, cmd("A, silenciar."))
        assertEquals(Command.Unmute, cmd("tirar do mudo"))
    }

    @Test fun palavraDeAtivacao() {
        assertEquals(Command.WakeOnly, cmd("A"))
        assertTrue(CommandParser.parse("A, pausar").hadWakeWord)
        assertTrue(!CommandParser.parse("pausar").hadWakeWord)
    }

    @Test fun melhorAlternativa() {
        val r = CommandParser.parseBest(listOf("blá blá", "a pausar"))
        assertEquals(Command.Pause, r.command)
    }
}
